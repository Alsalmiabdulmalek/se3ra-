// sw.js — network-first service worker. Always try the network so updates ship
// immediately; fall back to cache only when offline. Cache-first would freeze users
// on a stale build, which is the opposite of what we want during active development.
const CACHE = 'se3ra-v1';
const ASSETS = [
  './', './index.html', './styles.css', './app.js', './ai.js', './cloud.js',
  './nutrients.js', './i18n.js', './ingredients.js', './firebase-config.js',
  './manifest.webmanifest', './icons/icon-192.png', './icons/icon-512.png', './icons/icon-180.png',
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;                      // never cache POSTs (AI/Firebase)
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;       // let cross-origin (CDN, APIs) pass through

  e.respondWith(
    fetch(req)
      .then(res => {
        if (res && res.status === 200) {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put(req, copy));
        }
        return res;
      })
      .catch(() => caches.match(req).then(hit => hit || caches.match('./index.html')))
  );
});
